﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fit123
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var login = textBox1.Text;
            var password = textBox2.Text;
            if (login == string.Empty || password == string.Empty)
            {
                MessageBox.Show("Заполните все поля", "Ошибка");
                return;
            }
            //MessageBox.Show($"{login} {password}");
            //MessageBox.Show($"{AuthorizeUser(login, password)}");

            if (AuthorizeUser(login, password))
            {
                var dbQuery = new bd();

                string rule = "";

                using (SqlConnection con = new SqlConnection(dbQuery.StringCon()))
                {
                    con.Open();

                    using (SqlCommand command = new SqlCommand($"SELECT * FROM Сотрудники WHERE Логин ='{login}'", con))
                    {
                        //command.Parameters.Add(new SqlParameter("@login", login));
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            
                        }
                    }
                    if (rule == "")
                    {
                        Form2 mainfrm1 = new Form2();
                        mainfrm1.Show();
                        this.Hide();
                    }
                }

            }
            else
            {
                MessageBox.Show("Неверный логин или пароль.", "Ошибка");
            }

        }
        private bool AuthorizeUser(string login, string password)
        {
            bool isAuthorized = false;

            var dbQeury = new bd();


            using (SqlConnection con = new SqlConnection(dbQeury.StringCon()))
            {
                con.Open();
                using (SqlCommand command = new SqlCommand($"SELECT * FROM Сотрудники WHERE Логин ='{login}' and Пароль = '{password}'", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            if (reader["Пароль"].ToString() == password && reader["Логин"].ToString() == login)
                            {
                                isAuthorized = true;
                                MessageBox.Show("Вход успешно выполнен!", "Успех");
                            }
                        }
                    }
                }
            }
            return isAuthorized;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                textBox2.UseSystemPasswordChar = true;
            else
                textBox2.UseSystemPasswordChar = false;
        }
    }
}
