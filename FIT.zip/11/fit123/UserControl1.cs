﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fit123
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
            dateTimePicker1.Enabled = false;
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            if (label12.Text == "нет")
            {
                label12.ForeColor = Color.Red;
            }
            else
            {
                label12.ForeColor = Color.Green;
            }
        }
        public Label labelID
        {
            get { return label10; }
            set { label10 = value; }
        }

        public Label Age
        {
            get { return label11; }
            set { label11 = value; }
        }

        public Label labelClub
        {
            get { return label12; }
            set { label12 = value; }
        }
        public TextBox TBFIO
        {
            get { return textBox5; }
            set { textBox5 = value; }
        }

        public TextBox TBTel
        {
            get { return textBox4; }
            set { textBox4 = value; }
        }

        public TextBox TBProg
        {
            get { return textBox3; }
            set { textBox3 = value; }
        }

        public TextBox TBTren
        {
            get { return textBox2; }
            set { textBox2 = value; }
        }

        public DateTimePicker DTab
        {
            get { return dateTimePicker1; }
            set { dateTimePicker1 = value; }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
