﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fit123
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        string con = @"Data Source =0_311_11; Initial Catalog = FIT; Integrated Security = True";

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                SqlConnection sqlConnection = new SqlConnection(con);
                string chek = $"SELECT * FROM Клиент";

                try
                {

                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand(chek, sqlConnection))
                    {


                        SqlDataReader reader = command.ExecuteReader();


                        while (reader.Read())
                        {
                            UserControl1 cuc = new UserControl1();

                            cuc.labelID.Text = Convert.ToString(reader.GetInt32(0));
                            cuc.TBFIO.Text = reader.GetString(1);
                            cuc.Age.Text = Convert.ToString(reader.GetInt32(2));
                            cuc.TBTel.Text = reader.GetString(3);
                            cuc.TBProg.Text = reader.GetString(5);
                            cuc.TBTren.Text = reader.GetString(4);
                            cuc.labelClub.Text = reader.GetString(7);
                            cuc.DTab.Value = reader.GetDateTime(8);

                            flowLayoutPanel1.Controls.Add(cuc);
                        }


                    }
                    sqlConnection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка : {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
